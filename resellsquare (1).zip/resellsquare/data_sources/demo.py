"""
Demo Data Source for ResellSquare
Returns realistic fake data for validation
"""

import random
from typing import Dict, Any


class DemoDataSource:
    """Demo data source that returns realistic fake market data"""
    
    def fetch(self, query: str) -> Dict[str, Any]:
        """
        Generate realistic demo data
        
        Args:
            query: Product search query
            
        Returns:
            Dict with prices and metadata
        """
        
        # Generate realistic base price based on query
        base_price = self._estimate_base_price(query)
        
        # Generate 40-60 realistic prices around base
        num_prices = random.randint(42, 68)
        prices = self._generate_prices(base_price, num_prices)
        
        # Generate realistic titles
        titles = self._generate_titles(query, num_prices)
        
        return {
            'status': 'ok',
            'source': 'demo',
            'query': query,
            'prices': prices,
            'titles': titles[:5],  # First 5 for recent sales
            'count': len(prices)
        }
    
    def _estimate_base_price(self, query: str) -> float:
        """Estimate realistic base price from query"""
        
        query_lower = query.lower()
        
        # High-value items
        if any(word in query_lower for word in ['iphone', 'macbook', 'laptop', 'console', 'ipad']):
            return random.uniform(300, 800)
        
        # Mid-value items
        elif any(word in query_lower for word in ['airpods', 'watch', 'tablet', 'kindle', 'speaker']):
            return random.uniform(80, 250)
        
        # Low-value items
        elif any(word in query_lower for word in ['book', 'toy', 'game', 'card', 'accessory']):
            return random.uniform(15, 60)
        
        # Default mid-range
        else:
            return random.uniform(30, 100)
    
    def _generate_prices(self, base: float, count: int) -> list:
        """Generate realistic price distribution"""
        
        prices = []
        
        for _ in range(count):
            # 70% within 15% of base
            # 20% within 30% of base
            # 10% outliers
            
            rand = random.random()
            
            if rand < 0.7:
                variation = random.uniform(-0.15, 0.15)
            elif rand < 0.9:
                variation = random.uniform(-0.30, 0.30)
            else:
                variation = random.uniform(-0.50, 0.50)
            
            price = base * (1 + variation)
            prices.append(round(max(1.0, price), 2))
        
        return prices
    
    def _generate_titles(self, query: str, count: int) -> list:
        """Generate realistic product titles"""
        
        conditions = [
            'Excellent Condition',
            'Like New', 
            'Used - Good',
            'Brand New Sealed',
            'Fair Condition',
            'Very Good',
            'Mint',
            'Refurbished',
            'Open Box'
        ]
        
        extras = [
            'w/ Accessories',
            'Bundle',
            'Lot',
            'Free Shipping',
            'w/ Case',
            'Complete Set',
            'Original Packaging'
        ]
        
        titles = []
        
        for _ in range(count):
            # Base title
            title = query.title()
            
            # Add condition
            if random.random() > 0.3:
                title += f' - {random.choice(conditions)}'
            
            # Add extra
            if random.random() > 0.6:
                title += f' {random.choice(extras)}'
            
            titles.append(title)
        
        return titles


# Test
if __name__ == "__main__":
    print("Testing demo data source...")
    
    source = DemoDataSource()
    
    # Test various queries
    queries = ['AirPods Pro', 'Nintendo Switch', 'iPhone 13', 'Pokemon Cards']
    
    for query in queries:
        result = source.fetch(query)
        print(f"\n✓ Query: {query}")
        print(f"  Prices: {len(result['prices'])} items")
        print(f"  Range: ${min(result['prices']):.2f} - ${max(result['prices']):.2f}")
        print(f"  Sample title: {result['titles'][0]}")
    
    print("\nDemo data source tests passed! ✅")
