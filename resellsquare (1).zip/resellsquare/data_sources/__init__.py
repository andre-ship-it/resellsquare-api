"""
Data Sources for ResellSquare
"""

from .demo import DemoDataSource

__all__ = ['DemoDataSource']
